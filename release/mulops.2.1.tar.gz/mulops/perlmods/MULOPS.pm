package MULOPS;

# Richard Jamieson : 25/5/2016
# Based on functional spec (20160428-1)
# See: https://sourceforge.net/projects/mulops
# Catalogs in JSON format
# CATALOG: Valid operators :  Numeric(==,!=,<,>,<=,>=) String(eq,ne,lt,gt,le,ge) Match(=~ and value can be a RE)

use strict;
use base qw(Exporter);
@MULOPS::EXPORT = qw(mulops);
use warnings;
use JSON;

BEGIN {
    $MULOPS::VERSION = '1.10';
}


sub mulops {
   ###########################################################################################
   # If no mulops_command argument passed - then just list all avaliable commands/descriptions
   # Else - process the command + arguments
   my ($catalogs_ref,$mulops_command_arg,$docmode) = @_;
   my $mulops_output = "" ;
   my $catalog ;
   if( ! defined $mulops_command_arg ) {
      foreach $catalog (@$catalogs_ref) {
         if ( -r $catalog ) {
            $mulops_output .= sprintf("%-17s %s \n", "--catalog--", "$catalog");
            my $mulops_catalog = &getCatalog($catalog) ;
            my $cat_description = $mulops_catalog->{'catalog-description'} ;
            my $cat_version = $mulops_catalog->{'catalog-version'} ;
            
            my $mulops_commands = $mulops_catalog->{'mulops-commands'} ;
            foreach my $mulops_command (sort keys %{$mulops_commands}) {
                my $description = $mulops_catalog->{'mulops-commands'}->{$mulops_command}->{'description'} ;
                $mulops_output .= sprintf("%-17s %s \n", $mulops_command, $description);
            }
         }
      }
      return("$mulops_output");
   } else {
      foreach $catalog (@$catalogs_ref) {
         if ( -r $catalog ) {
            my $mulops_catalog = &getCatalog($catalog) ;
            my $mulops_oscommand_variations = $mulops_catalog->{'mulops-commands'}->{$mulops_command_arg}->{'oscommands'} ; # Array
            if ($mulops_oscommand_variations) { 
               foreach my $oscommand_index (0 .. $mulops_oscommand_variations) {
                  my @mulops_oscommand_variation_fields = (keys %{$mulops_oscommand_variations->[$oscommand_index]});
                  # all fields except "oscommand" are used as "selectors" (ie: lookup values )
                  my @oscommand_selector_fields = grep !/oscommand/, @mulops_oscommand_variation_fields;
                  my $selectors_match = "yes" ;
                  foreach my $oscommand_selector_field (@oscommand_selector_fields) {
                     my $cat_selector_operator = $mulops_oscommand_variations->[$oscommand_index]->{$oscommand_selector_field}->[0];
                     my $cat_selector_val = $mulops_oscommand_variations->[$oscommand_index]->{$oscommand_selector_field}->[1];
                     my $mulops_selector_value = &mulops(\@$catalogs_ref,$oscommand_selector_field,"no") ;
                     chomp($mulops_selector_value);
                     my $match_test="\"$mulops_selector_value\" $cat_selector_operator \"$cat_selector_val\"";
                     if ( ! eval $match_test ) {
                        $selectors_match = "no" ;
                        last ;   # Skip to the next oscommand variation in the catalog
                     }
                  }
                  if ( "$selectors_match" eq "no" ) {
                     next ;
                  }
   
                  my $mulops_oscommand_variation = $mulops_oscommand_variations->[$oscommand_index]->{'oscommand'};
                  if ($mulops_oscommand_variation) {
                     if ($docmode eq "yes") {
                        # Display the OS command
                        $mulops_output = $mulops_oscommand_variation . "\n" ;
                     } else {
                        # Execute the OS command
                        $mulops_output = `$mulops_oscommand_variation` if defined($mulops_oscommand_variation);
                     }
                  }
                  #---------------------------------------------------------------------------------------------
                  # Add option to print out the json that resulted in the match ( LATER ! )
                  # my $json_text = &JSON::to_json($mulops_oscommand_variations->[$oscommand_index], {utf8 => 1, pretty => 1}) ;
                  # print "$json_text \n";
                  #---------------------------------------------------------------------------------------------
                  return("$mulops_output");
                  last ;
               }
            }
         }
      }
   }
}
###########################################################################################
# Params = catalog
# Return = hashref
sub getCatalog {
   # Can add another parameter later - to signify format and maybe source of catalog
   my ($catalog) = @_;
   my $json;
   {
      local $/; #Enable 'slurp' mode
      open my $fh, "<", "$catalog";
      $json = <$fh>;
      close $fh;
   }
   my $mulops_catalog = from_json($json);
   return $mulops_catalog ;
}

1;
__END__

=head1 NAME

 mulops - Multi Operating System tool
          Simple consistent commands..

=head1 SYNOPSIS

 use MULOPS;	# Imports "mulops" subroutine
 my $mulops_output = &mulops(\@catalogs,$mulops_command_arg,$docmode) ;
 print "$mulops_output" ;

 ------------------------------------------------------------------------
 @catalogs:	 	array of mulops JSON catalog names
 $mulops_command_arg:	mulops command argument
 $docmode:		["yes"|"no"]
			If "no", the oscommand is executed.
			If "yes", the oscommands is displayed only.

=head1 DESCRIPTION

 Different operating systems have different ways of doing the same thing.
 ( eg: showing total amount of system memory ).
 This tool aims to help to provide a consistent way to do the same things
 across multiple operating systems.
 The tool can be used for one-off commands, to create portable system
 programs, or just for education

=head1 INSTALL

 Copy this module to a directory in your $PERL5LIB search path.

=head1 AUTHORS

 Richard Jamieson richard.jamieson@scsuk.net


