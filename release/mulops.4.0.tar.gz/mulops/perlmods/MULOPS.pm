package MULOPS;
# Richard Jamieson : 16/6/2016
# Based on functional spec (20160428-1)
# See: https://sourceforge.net/projects/mulops
# Catalogs in JSON format
# CATALOG: Valid operators :  Numeric(==,!=,<,>,<=,>=) String(eq,ne,lt,gt,le,ge) Match(=~ and value can be a RE)

use strict;
use base qw(Exporter);
@MULOPS::EXPORT = qw(mulops);
use warnings;
use JSON;
use HTTP::Lite;
use Capture::Tiny::Extended qw/capture tee capture_merged tee_merged/;


BEGIN {
    $MULOPS::VERSION = '4.00';
}

sub mulops {
   ###########################################################################################
   # If no mulops_command argument passed - then just list all avaliable commands/descriptions
   # Else - process the command + arguments
   my ($catalogs_ref,$mulops_command_arg,$mulops_mode);
   my $catalog_cache = {};
   my $mulops_output_cache = {};
   ($catalogs_ref,$mulops_command_arg,$mulops_mode,$catalog_cache,$mulops_output_cache) = @_;
   
   my $mulops_output = "" ;
   my $catalog ;
   if( $mulops_command_arg eq "all" ) {
      foreach $catalog (@$catalogs_ref) {
         if (( -r $catalog ) || ( $catalog =~ "^http:" )) {
            $mulops_output .= sprintf("%-17s %s \n", "--catalog--", "$catalog");
            my $mulops_catalog = &getCatalog($catalog) ;
            my $cat_description = $mulops_catalog->{'catalog-description'} ;
            my $cat_version = $mulops_catalog->{'catalog-version'} ;
            my $cat_author = $mulops_catalog->{'author'} ;
            
            my $mulops_commands = $mulops_catalog->{'mulops-commands'} ;
            foreach my $mulops_command (sort keys %{$mulops_commands}) {
                my $description = $mulops_catalog->{'mulops-commands'}->{$mulops_command}->{'description'} ;
                $mulops_output .= sprintf("%-17s %s \n", $mulops_command, ": $description");
            }
         }
      }
      chomp($mulops_output);
      $mulops_output_cache->{$mulops_command_arg}->{description} = $mulops_output ;
      #return("$mulops_output",$mulops_output_cache);
      return($mulops_output_cache) if defined($mulops_output_cache);
   } else {
      foreach $catalog (@$catalogs_ref) {
         if (( -r $catalog ) || ( $catalog =~ "^http:" )) {
            #print "Catalog: $catalog \n";
            my $mulops_catalog;
            if (! defined($catalog_cache->{$catalog})) {
               #print "Cache Add : $catalog \n";
               $mulops_catalog = &getCatalog($catalog) ;
               $catalog_cache->{$catalog} = $mulops_catalog;
            } else {
               #print "Cache Find : $catalog \n";
               $mulops_catalog = $catalog_cache->{$catalog} ;
            }
            my $cat_description = $mulops_catalog->{'catalog-description'} ;
            my $cat_version = $mulops_catalog->{'catalog-version'} ;
            my $cat_author = $mulops_catalog->{'author'} ;
            my $mulops_oscommand_variations = $mulops_catalog->{'mulops-commands'}->{$mulops_command_arg}->{'variations'} ; # Array
            my $mulops_oscommand_description = $mulops_catalog->{'mulops-commands'}->{$mulops_command_arg}->{'description'} ; # Scalar
            if ($mulops_oscommand_variations) { 
               foreach my $oscommand_index (0 .. $mulops_oscommand_variations) {
                  my @mulops_oscommand_variation_fields = (keys %{$mulops_oscommand_variations->[$oscommand_index]});
                  # all fields except "oscommand" are used as "selectors" (ie: lookup values )
                  my @oscommand_selector_fields = grep !/oscommand/, @mulops_oscommand_variation_fields;
                  my $selectors_match = "yes" ;
                  foreach my $oscommand_selector_field (@oscommand_selector_fields) {
                     my $cat_selector_operator = $mulops_oscommand_variations->[$oscommand_index]->{$oscommand_selector_field}->[0];
                     my $cat_selector_val = $mulops_oscommand_variations->[$oscommand_index]->{$oscommand_selector_field}->[1];
                     my ($mulops_output_cache) = &mulops(\@$catalogs_ref,$oscommand_selector_field,"no",$catalog_cache,\%$mulops_output_cache) ;
                     my $mulops_selector_value = $mulops_output_cache->{$oscommand_selector_field}->{execute};
                     #chomp($mulops_selector_value);
                     my $match_test="\"$mulops_selector_value\" $cat_selector_operator \"$cat_selector_val\"";
                     if ( ! eval $match_test ) {
                        $selectors_match = "no" ;
                        last ;   # Skip to the next oscommand variation in the catalog
                     }
                  }
                  if ( "$selectors_match" eq "no" ) {
                     next ;
                  }
   
                  my $mulops_oscommand_variation = $mulops_oscommand_variations->[$oscommand_index]->{'oscommand'};
                  if ($mulops_oscommand_variation) {
                     if ($mulops_mode eq "catalog") {
                        # Print out the catalog entry that releates to the mulops-command
                        $mulops_output = sprintf("%-19s %s \n", "# $mulops_command_arg", ": $mulops_oscommand_description");
                        $mulops_output .= sprintf("%-19s %s \n",  "# Catalog",     ": $catalog");
                        $mulops_output .= sprintf("%-19s %s \n", "# Version",     ": $cat_version");
                        $mulops_output .= sprintf("%-19s %s \n", "# Description", ": $cat_description");
                        $mulops_output .= sprintf("%-19s %s \n", "# Author",      ": $cat_author");
                        $mulops_output .= to_json($mulops_oscommand_variations->[$oscommand_index], {utf8 => 1, pretty => 1}) ;
                        $mulops_output_cache->{$mulops_command_arg}->{catalog} = $mulops_output ;
                     } elsif ($mulops_mode eq "description") {
                        # Display the OS command
                        $mulops_output = $mulops_oscommand_description ;
                        $mulops_output_cache->{$mulops_command_arg}->{description} = $mulops_oscommand_description ;
                     } elsif ($mulops_mode eq "oscommand") {
                        # Display the OS command
                        $mulops_output = $mulops_oscommand_variation ;
                        $mulops_output_cache->{$mulops_command_arg}->{oscommand} = $mulops_oscommand_variation ;
                     } elsif ( defined($mulops_output_cache->{$mulops_command_arg}->{execute})) {
                        #print "From cache: $mulops_command_arg \n" ;
                        $mulops_output = $mulops_output_cache->{$mulops_command_arg}->{execute};
                     } else {
                        # print "Execute: $mulops_command_arg \n" ; # very useful debug line for checking the cacheing !
                        # Execute the OS command
                        #$mulops_output = `$mulops_oscommand_variation` if defined($mulops_oscommand_variation);
                        my ($stdout, $stderr, $return) = capture {
                           return system( $mulops_oscommand_variation );
                        };
                        if ( $return != 0 ) {
                           print "FAILURE: mulops($mulops_command_arg),catalog($catalog)\n";
                           print "COMMAND: $mulops_oscommand_variation\n";
                           print "STDERR_: $stderr";
                           exit $return;
                        }
                        chomp($stdout);
                        $mulops_output = $stdout ;
                        $mulops_output_cache->{$mulops_command_arg}->{oscommand} = $mulops_oscommand_variation ;
                        $mulops_output_cache->{$mulops_command_arg}->{execute} = $mulops_output ;
                     }
                  }
                  #---------------------------------------------------------------------------------------------
                  #return("$mulops_output",$mulops_output_cache) if defined($mulops_output);
                  return($mulops_output_cache) if defined($mulops_output_cache);
                  last ;
               }
            }
         }
      }
   }
   # mulops-commands specified - and it does nto exist in any catalogs
   $mulops_output_cache->{$mulops_command_arg}->{description} = "NoCatalogEntry" ;
   $mulops_output_cache->{$mulops_command_arg}->{oscommand} = "NoCatalogEntry" ;
   $mulops_output_cache->{$mulops_command_arg}->{execute} = "NoCatalogEntry" ;
   $mulops_output_cache->{$mulops_command_arg}->{catalog} = "NoCatalogEntry" ;
   return($mulops_output_cache) if defined($mulops_output_cache);
}
###########################################################################################
# Params = catalog
# Return = hashref
sub getCatalog {
   # Can add another parameter later - to signify format and maybe source of catalog
   my ($catalog) = @_;
   #print "Get Catalog : $catalog \n";
   my $mulops_catalog ;
   #      if (( -r $catalog ) || ( $catalog =~ "^http:" )) {
   if ( $catalog =~ "^http:" ) {
      my $http = HTTP::Lite->new;
      my $req = $http->request("$catalog") or die "Unable to get document: $!";
      die "Request failed ($req): ".$http->status_message() if $req ne "200";
      my $mulops_url_data = $http->body();
      $mulops_catalog = from_json($mulops_url_data);
   } else {
     my $mulops_file_data;
     local $/; #Enable 'slurp' mode
     open my $fh, "<", "$catalog";
     $mulops_file_data = <$fh>;
     close $fh;
     $mulops_catalog = from_json($mulops_file_data);
   }
   return $mulops_catalog ;
}

1;
__END__

=head1 NAME

 mulops - Multi Operating System tool
          Simple consistent commands..

=head1 SYNOPSIS

 use MULOPS;	# Imports "mulops" subroutine

 ($mulops_output_cache) = mulops(\@catalogs,$mulops_command_arg,$mulops_mode,$catalog_cache,$mulops_output_cache) ;

 ------------------------------------------------------------------------
 @catalogs:	 	array of mulops JSON catalog names
 $mulops_command_arg:	mulops command argument
 $mulops_mode:		["execute"|"oscommand"|"catalog"]
			execute:  the oscommand is executed.
			oscommand: the oscommands is displayed only.
			catalog:  the catalog entry for the command is displayed.
 $catalog_cache:	Can pass cached catalogs.
			Only expect this to be used by mulops itself for recursion routines.
 $mulops_output_cache   Can pass cached mulops results ( eg: descriptions, oscommands and execution-output )
			$mulops_output_cache->{$mulops-command}->{"description"}
			$mulops_output_cache->{$mulops-command}->{"oscommand"}
			$mulops_output_cache->{$mulops-command}->{"execute"}

=head1 DESCRIPTION

 Different operating systems have different ways of doing the same thing.
 ( eg: showing total amount of system memory ).
 This tool aims to help to provide a consistent way to do the same things
 across multiple operating systems.
 The tool can be used for one-off commands, to create portable system
 programs, or just for education

=head1 INSTALL

 Follow instructions in "mulops readme" - or...
 Copy this module to a directory in your $PERL5LIB search path.

=head1 AUTHORS

 Richard Jamieson richard.jamieson@scsuk.net


