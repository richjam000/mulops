package MULOPS;

# Richard Jamieson : 23/5/2016
# Based on functional spec (20160428-1)
# See: https://sourceforge.net/projects/mulops
# Catalogues in JSON format
# CATALOGUE: Valid operators :  Numeric(==,!=,<,>,<=,>=) String(eq,ne,lt,gt,le,ge) Match(=~ and value can be a RE)

use strict;
#use Carp ();
use base qw(Exporter);
@MULOPS::EXPORT = qw(mulops);
use warnings;
#use File::Basename;
#use File::Spec;
use JSON;

BEGIN {
    $MULOPS::VERSION = '1.00';
}


sub mulops {
   ###########################################################################################
   # If no mulops_command argument pased - then just list all avaliable commands/descriptions
   # Else - process the command + arguments
   my ($catalogues_ref,$mulops_command_arg,$docmode) = @_;
   my $mulops_output ;
   #print "DEBUG: catalogues: @$catalogues_ref \n";
   #print "DEBUG: mulops_command_arg: $mulops_command_arg \n";
   #print "DEBUG: docmode: $docmode \n";
   my $catalogue ;
   if( ! defined $mulops_command_arg ) {
      foreach $catalogue (@$catalogues_ref) {
         if ( -r $catalogue ) {
            $mulops_output .= sprintf("%-17s %s \n", "--catalogue--", "$catalogue");
            my $mulops_catalogue = &getCatalogue($catalogue) ;
            my $cat_description = $mulops_catalogue->{'catalogue-description'} ;
            my $cat_version = $mulops_catalogue->{'catalogue-version'} ;
            
            my $mulops_commands = $mulops_catalogue->{'mulops-commands'} ;
            foreach my $command (sort keys $mulops_commands) {
                my $description = $mulops_catalogue->{'mulops-commands'}->{$command}->{'description'} ;
                $mulops_output .= sprintf("%-17s %s \n", $command, $description);
            }
         }
      }
      return("$mulops_output");
   } else {
      foreach $catalogue (@$catalogues_ref) {
         if ( -r $catalogue ) {
            my $mulops_catalogue = &getCatalogue($catalogue) ;
            my $mulops_oscommand_variations = $mulops_catalogue->{'mulops-commands'}->{$mulops_command_arg}->{'oscommands'} ;
            if (defined($mulops_oscommand_variations)) { 
               foreach my $mulops_oscommand_variation_index (keys $mulops_oscommand_variations) {
                  my $mulops_oscommand_variation = $mulops_oscommand_variations->[$mulops_oscommand_variation_index]->{'oscommand'};
                  my @mulops_oscommand_variation_fields = keys($mulops_oscommand_variations->[$mulops_oscommand_variation_index]);
                  # all fields except "oscommand" are used as "selectors" (ie: lookup values )
                  my @mulops_oscommand_variation_selector_fields = grep !/oscommand/, @mulops_oscommand_variation_fields;
                  my $selectors_match = "yes" ;
                  foreach my $mulops_oscommand_variation_selector_field (@mulops_oscommand_variation_selector_fields) {
                     my $cat_selector_operator = $mulops_oscommand_variations->[$mulops_oscommand_variation_index]->{$mulops_oscommand_variation_selector_field}->[0];
                     my $cat_selector_val = $mulops_oscommand_variations->[$mulops_oscommand_variation_index]->{$mulops_oscommand_variation_selector_field}->[1];
                     my $mulops_selector_value = &mulops(\@$catalogues_ref,$mulops_oscommand_variation_selector_field,"no") ;
                     chomp($mulops_selector_value);
                     #print "DEBUG: mulops_selector_value : $mulops_selector_value \n";
                     my $match_test="\"$mulops_selector_value\" $cat_selector_operator \"$cat_selector_val\"";
                     if ( ! eval $match_test ) {
                        $selectors_match = "no" ;
                        last ;   # Skip to the next oscommand variation in the catalogue
                     }
                  }
                  if ( $selectors_match eq "no" ) {
                     next ;
                  }
   
                  if ($docmode eq "yes") {
                     # Display the OS command
                     $mulops_output = $mulops_oscommand_variation . "\n" ;
                  } else {
                     # Execute the OS command
                     $mulops_output = `$mulops_oscommand_variation 2>&1` ;
                  }
                  #---------------------------------------------------------------------------------------------
                  # Add option to print out the json that resulted in the match ( LATER ! )
                  # my $json_text = &JSON::to_json($mulops_oscommand_variations->[$mulops_oscommand_variation_index], {utf8 => 1, pretty => 1}) ;
                  # print "$json_text \n";
                  #---------------------------------------------------------------------------------------------
                  return("$mulops_output");
                  last ;
               }
            }
         }
      }
   }
}
###########################################################################################
# Params = catalogue
# Return = hashref
sub getCatalogue {
   # Can add another parameter later - to signify format and maybe source of catalogue
   my ($catalogue) = @_;
   my $json;
   {
      local $/; #Enable 'slurp' mode
      open my $fh, "<", "$catalogue";
      $json = <$fh>;
      close $fh;
   }
   my $mulops_catalogue = &JSON::from_json($json);
   return $mulops_catalogue ;
}

1;
__END__

=head1 NAME

 mulops - Multi Operating System tool
          Simple consistent commands..

=head1 SYNOPSIS

 use MULOPS;	# Imports "mulops" subroutine
 my $mulops_output = &mulops(\@catalogues,$mulops_command_arg,$docmode) ;
 print "$mulops_output" ;

 ------------------------------------------------------------------------
 @catalogues:	 	array of mulops JSON catalogue names
 $mulops_command_arg:	mulops command argument
 $docmode:		["yes"|"no"]
			If "no", the oscommand is executed.
			If "yes", the oscommands is displayed only.

=head1 DESCRIPTION

 Different operating systems have different ways of doing the same thing.
 ( eg: showing total amount of system memory ).
 This tool aims to help to provide a consistent way to do the same things
 across multiple operating systems.
 The tool can be used for one-off commands, to create portable system
 programs, or just for education

=head1 INSTALL

 Copy this module to a directory in your $PERL5LIB search path.

=head1 AUTHORS

 Richard Jamieson richard.jamieson@scsuk.net


